async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message } = messageInfo;
  if (!isGroup) return; // Only Grub

  await sock.sendMessage(
    remoteJid,
    { text: `🔊 hallo  
    
     
       'Hidup emang, kayak' 
     'cicak-cicak di, dinding' 
     'diam-diam sad' ending (:'

> TIKTOK 💬 @itsdoo172
> Owner  📞 https://wa.me/6282172992548 

 website untuk liat harga sewa bot
🌐 https://website-hosting-alstore17.vercel.app/` },
    { quoted: message }
  );
}
export default {
  handle,
  Commands: ["bot", "p"],
  OnlyPremium: true,
  OnlyOwner: true,
};
