import { reply } from "../../lib/utils.js";
import config from "../../config.js";

async function handle(sock, messageInfo) {
  const { m } = messageInfo;

  const text = `╭「 𝙇𝙄𝙎𝙏 𝙋𝙍𝙊𝘿𝙐𝙆 𝘼𝙇 」
│
│◧ ├─❐ 𝐋𝐈𝐒𝐓 𝐇𝐀𝐑𝐆𝐀 𝐏𝐀𝐍𝐄𝐋
│  📦 𝗥𝗔𝗠 1 GB 𝗥𝗽 1.000
│ ◉📦 𝗥𝗔𝗠 2 GB 𝗥𝗽 1.500
│ ◉📦 𝗥𝗔𝗠 3 GB 𝗥𝗽 2.000
│ ◉📦 𝗥𝗔𝗠 4 GB 𝗥𝗽 2.500
│ ◉📦 𝗥𝗔𝗠 5 GB 𝗥𝗽 3.000
│ ◉📦 𝗥𝗔𝗠 6 GB 𝗥𝗽 4.000
│ ◉📦 𝗥𝗔𝗠 7 GB 𝗥𝗽 4.500
│ ◉📦 𝗥𝗔𝗠 8 GB 𝗥𝗽 6.000
│ ◉📦 𝗥𝗔𝗠 9 GB 𝗥𝗽 7.000
│ ◉📦 𝗥𝗔𝗠 10 GB 𝗥𝗽 8.000
│ ◉📦 𝗥𝗔𝗠 UNLI 𝗥𝗽 10.000  
├───────────────────❐
>  𝐌𝐈𝐍𝐀𝐓? 𝐂𝐇𝐀𝐓 𝐀𝐉𝐀 𝐔𝐘𝐘🥳
├───────────────────❐
├─❐ SEWA BOT WA 
│ ◉ 1-2 Hari = 3k-6k
│ ◉ 1 Minggu = 10k
│ ◉ 2 Minggu = 15k 
│ ◉ 3 Minggu = 20k
│ ◉ 1 Bullann = 25k
│ ◉ 2 Bullann = 30k
│ ◉ Dll 
└───────────────────❐
┌───────────────────❐
├─❐ *𝐂𝐎𝐍𝐓𝐀𝐂𝐓 𝐌𝐄👇*
└───────────────────❐
*[ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 ]*
https://wa.me/+6282381215184
https://wa.me/+6282172992548

╭「 Link website list panel / sewa bot」

◧ ᴡᴇʙꜱɪᴛᴇ https://website-hosting-alstore17.vercel.app/`;
"https://files.catbox.moe/nhx1dw.jpg"
"https://files.catbox.moe/xy1bsp.jpg"

  await reply(m, text);
}

export default {
  handle,
  Commands: ["buy"],
  OnlyPremium: false,
  OnlyOwner: false,
};
