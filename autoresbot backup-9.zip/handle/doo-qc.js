/**
‎✧ Name   : quotes kata-kata
‎✧ Creator   : Triaa Gemoy🧚‍♀️
‎✧
‎**/

import axios from 'axios';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`cara pakai *${usedPrefix + command}* :\n\n` +
            `format: *${usedPrefix + command} teks quotes|nama*\n` +
            `contoh: *${usedPrefix + command} ketika kamu kesepian, carilah dirimu sendiri|Triaa*\n`
        );
    }

    const [quotesPayload, namaPayload] = text.split('|');
    if (!quotesPayload) return m.reply(`Format salah beb! Sediakan teks quotes.\nContoh: *${usedPrefix + command} Tetap menyerah jangan semangat🗿|Triaa*`);

    const txt = quotesPayload.trim();
    const namaStr = namaPayload ? namaPayload.trim() : '';

    await conn.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });

    try {
        const RIN_BG_URL = 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/IMG-20260703-WA0651.jpg';
        const RIN_DIR = join(process.cwd(), 'assets', 'rinchat');
        const RIN_BG_LOCAL = join(RIN_DIR, 'quotes-bg.jpg');
        const RIN_TMP = join(process.cwd(), 'tmp');

        await mkdir(RIN_DIR, { recursive: true });
        await mkdir(RIN_TMP, { recursive: true });

        if (!existsSync(RIN_BG_LOCAL)) {
            const res = await axios.get(RIN_BG_URL, { 
                responseType: 'arraybuffer', 
                headers: { 'User-Agent': 'Mozilla/5.0' },
                maxRedirects: 5 
            });
            await writeFile(RIN_BG_LOCAL, Buffer.from(res.data));
        }

        const canvas = createCanvas(1280, 946);
        const ctx = canvas.getContext('2d');
        const bgImg = await loadImage(RIN_BG_LOCAL);
        ctx.drawImage(bgImg, 0, 0, 1280, 946);
        
        const textX = 105;
        const maxWidth = 500;
        const fontSize = 54;
        const gapY = 45;
        const colorText = "#004d26";
        const colorNama = "#2e7d32";
        ctx.font = `bold ${fontSize}px sans-serif`;
        const lineHeight = fontSize * 1.3;

        function wrapText(text, maxWidth) {
            const words = text.split(' ');
            const lines = [];
            let currentLine = '';

            for (let i = 0; i < words.length; i++) {
                let testLine = currentLine + (currentLine ? ' ' : '') + words[i];
                if (ctx.measureText(testLine).width > maxWidth && currentLine) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            if (currentLine) lines.push(currentLine);
            return lines;
        }

        const lines = wrapText(txt, maxWidth);
        const availableHeight = 850 - 100; 
        const totalTextHeight = lines.length * lineHeight;
        const totalCombinedHeight = totalTextHeight + (namaStr ? (gapY + 34) : 0);

        let autoTextY = 100 + ((availableHeight - totalCombinedHeight) / 2);
        if (autoTextY < 100) autoTextY = 100;

        ctx.fillStyle = colorText;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';

        for (let i = 0; i < lines.length; i++) {
            ctx.fillText(lines[i].trim(), textX, autoTextY + (i * lineHeight));
        }

        if (namaStr) {
            const autoUsernameY = autoTextY + totalTextHeight + gapY;
            const autoUsernameX = (textX + (maxWidth / 3)) - (maxWidth * 0.03);
            
            ctx.fillStyle = colorNama;
            ctx.font = `bold 34px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            
            ctx.fillText(`— ${namaStr}`, autoUsernameX, autoUsernameY);
        }

        const rinOut = join(RIN_TMP, `quotes-${Date.now()}.png`);
        await writeFile(rinOut, await canvas.encode('png'));

        await conn.sendMessage(m.chat, {
            image: { url: rinOut },
            caption: '_Quotes Berhasil~ 🌸_'
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        if (existsSync(rinOut)) await writeFile(rinOut, '');

    } catch (e) {
        console.error('quotes error:', e.message || e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        throw '❌ Gagal memproses gambar Quotes!';
    }
};

handler.help = ['qcv2'];
handler.tags = ['maker'];
handler.command = /^(qcv2)$/i;
handler.limit = true;
handler.register = true;

export default handler;