/*
╔══════════════════════════════════════════════╗
║    sᴄʀɪᴘᴛ ᴠɪᴏɴɪx ʙʏ ᴀʟ ʜɪɢʜ🦅           🌐   https://website-al-store.vercel.app//                     ║
╠══════════════════════════
    𝙽𝙾 𝙳𝙴𝙻𝚃𝙴 𝚆𝙼 𝙼𝙴𝙼𝙴𝙺
════════════════════╣
*/

import moment from "moment-timezone";

const CONNECTION = "pairing"; // qr atau pairing
const OWNER_NAME = "𝐃𝐨𝐨ᴴᴰ || 𝐏𝐄";
const NOMOR_BOT = "6283829563828"; // 628xx nomor wa
const DESTINATION = "group"; // group , private, both
const APIKEY = ""; // apikey dari autoresbot.com (paket apikey)
const RATE_LIMIT = 3000; // 3 detik/chat
const SIMILARITY = true; // Pencarian kemiripan command (true, false)
const MODE = "production"; // [production, development] (jangan di ubah kecuali anda developer)
const VERSION = global.version; // don't edit

const EMAIL = "itsdoo24@gmail.com";
const REGION = "Indonesia";
const WEBSITE = "https://website-al-store.vercel.app/";
const DATA_OWNER = ["6282172992548"];

// Konfiqurasi Chat
const ANTI_CALL = true; // jika true (setiap yang nelpon pribadi akan di block)
const AUTO_READ = true; // jika true (setiap chat akan di baca/centang 2 biru)
const AUTO_BACKUP = true; // jika true (setiap restart server, data backup di kirimkan ke wa owner);
const MIDNIGHT_RESTART = true; // Restart setiap jam 12 malam
const PRESENCE_UPDATE = "up"; // unavailable, available, composing, recording, paused
const TYPE_WELCOME = "5"; // 1, 2, 3, 4, 5, 6 text dan random
const BG_WELCOME2 = "https://api.autoresbot.com/api/maker/bg-default";

// Konfiqurasi Panel
const PANEL_URL = "";
const PANEL_PLTA = "";
const PANEL_DESCRIPTION = "Butuh Bantuan Hubungi 6282381215184";
const PANEL_ID_EGG = 15;
const PANEL_ID_LOCATION = 1;
const PANEL_DEFAULT_DISK = 5120; // 5GB atau 0 (unlimited)
const PANEL_DEFAULT_CPU = 90;

// antibadword di grub
const BADWORD_WARNING = 3; // Jumlah maksimum peringatan sebelum tindakan diambil
const BADWORD_ACTION = "both"; // tindakan setelah warning terpenuhi (kick, block, both)

// antispam di grub
const SPAM_LIMIT = 3; // Batas pesan dianggap spam
const SPAM_COULDOWN = 10; // Waktu cooldown dalam detik (10 detik)
const SPAM_WARNING = 3; // Jumlah maksimum peringatan sebelum tindakan diambil
const SPAM_ACTION = "both"; // tindakan setelah warning terpenuhi (kick, block, both)

// More
const STATUS_SCHEDULED = true;

const config = {
  APIKEY,
  phone_number_bot: NOMOR_BOT,
  type_connection: CONNECTION,
  bot_destination: DESTINATION,
  owner_name: OWNER_NAME,
  owner_number: DATA_OWNER,
  owner_website: WEBSITE,
  owner_email: EMAIL,
  region: REGION,
  version: VERSION,
  rate_limit: RATE_LIMIT,
  status_prefix: true, // wajib prefix : atau false tanpa prefix
  prefix: [".", "!", "#"],
  sticker_packname: OWNER_NAME,
  sticker_author: `Date: ${moment
     .tz("Asia/Riau")
    .format("DD/MM/YY")}\n𝘗𝘰𝘸𝘦𝘳𝘧𝘶𝘭𝘭: © DooHigh!\n404`,
  mode: MODE,
  commandSimilarity: SIMILARITY,
  anticall: ANTI_CALL,
  autoread: AUTO_READ,
  autobackup: AUTO_BACKUP,
  PresenceUpdate: PRESENCE_UPDATE,
  typewelcome: TYPE_WELCOME,
  bgwelcome2: BG_WELCOME2,
  midnight_restart: MIDNIGHT_RESTART,
  scheduled: STATUS_SCHEDULED,
  PANEL: {
    URL: PANEL_URL,
    KEY_APPLICATION: PANEL_PLTA,
    description: PANEL_DESCRIPTION,
    SERVER_EGG: PANEL_ID_EGG,
    id_location: PANEL_ID_LOCATION,
    default_disk: PANEL_DEFAULT_DISK,
    cpu_default: PANEL_DEFAULT_CPU,
  },
  SPAM: {
    limit: SPAM_LIMIT,
    couldown: SPAM_COULDOWN,
    warning: SPAM_WARNING,
    action: SPAM_ACTION,
  },
  BADWORD: {
    warning: BADWORD_WARNING,
    action: BADWORD_ACTION,
  },
};

export default config;
